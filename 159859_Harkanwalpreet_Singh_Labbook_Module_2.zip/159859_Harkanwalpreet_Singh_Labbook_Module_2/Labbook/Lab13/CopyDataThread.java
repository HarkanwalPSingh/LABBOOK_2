import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread implements Runnable
{
	

		FileInputStream fromFile;
		FileOutputStream toFile;

		public void init(String arg1, String arg2) {
			//Assign the files
			try {
				fromFile = new FileInputStream(arg1);
				toFile = new FileOutputStream(arg2);
			} catch (FileNotFoundException fnfe) {
				System.out.println("Exception: " + fnfe);
				return;
			}  catch (ArrayIndexOutOfBoundsException aioe) {
				System.out.println("Exception: " + aioe);
				return;
			}

		}

		public void copyContents() throws InterruptedException {

			// copy bytes
			try {
				int i = fromFile.read();
				int  count = 0;
				while (i != -1) { //check the end of file
					toFile.write(i);
					i = fromFile.read();
					count++;
					if(count==10)
					{
						System.out.println("10 characters copied.");
						count = 0;
						Thread.sleep(1000);
					}
				}
				System.out.println("file copied successfully.");
			} catch (IOException ioe) {
				System.out.println("Exception: " + ioe);
				return;
			}
		}

		public void closeFiles() {

			//close the files
			try {
				fromFile.close();
				toFile.close();

			} catch (IOException ioe) {
				System.out.println("Exception: " + ioe);
				return;
			}
		}

		

		@Override
		public void run()
		{
			CopyDataThread c1 = new CopyDataThread();
			c1.init("D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson8\\source.txt", "D:\\Labwork 153062 YashGeel\\Labwork 153062 Yash Geel\\src\\com\\capgemini\\lesson8\\target.txt");
			try {
				c1.copyContents();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			c1.closeFiles();
		}
}

