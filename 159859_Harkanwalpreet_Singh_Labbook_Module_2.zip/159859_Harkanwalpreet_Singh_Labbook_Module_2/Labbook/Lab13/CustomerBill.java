//Write a program using Inter Thread Communication for Electronic shop. In the billing counter first customer gives products for billing and the billing counter person should wait for him. Once he receives the products the billing person then bills the products
//Expected output: Customer giving products to billing person
//Billing person bills the products.






class customer extends Thread
{
	@Override
	public void run() 
	{
		System.out.println("Customer giving products to billing person");
		super.run();
	}
}


class Biller extends Thread
{
	@Override
	public void run() 
	{
		System.out.println("Billing person bills the products.");
		super.run();
	}
}

public class CustomerBill 
{
	public static void main(String[] args) throws InterruptedException 
	{
		for(int i=0;i<5;i++){
		customer cc = new customer();
		Thread t1 = new Thread(cc);
		t1.start();
		
		Thread.sleep(1000);
		
		Biller bb = new Biller();
		Thread t2 = new Thread(bb);
		t2.start();
		Thread.sleep(1000);
		}
		
	}
}
