package lab7;

public class Lab7_1 {

	public static void main(String[] args) {
		

	}

}
