package com.cg.fileIO;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseContent {

	public static void main(String[] args) throws IOException {
		File file1 = new File(
				".\\TEST1.txt");
		File file2 = new File(
				".\\TEST2.txt");
		FileInputStream fromFile = new FileInputStream(file1);
		FileOutputStream toFile = new FileOutputStream(file2);

		int i = fromFile.read();
		int count = 0;

		String st = "" + (char) i;

		while (i != -1) { // check the end of file
			// toFile.write(i);
			i = fromFile.read();
			st = st + (char) i;
		}

		for (int j = st.length() - 2; j >= 0; j--) {
			int k = st.charAt(j);
			toFile.write(k);
		}
		System.out.println(st);
	}

}
