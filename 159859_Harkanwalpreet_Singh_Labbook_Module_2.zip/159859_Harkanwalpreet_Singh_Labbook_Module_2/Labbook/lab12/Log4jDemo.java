import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Log4jDemo {

	public static void main(String[] args) {
		PropertyConfigurator.configure(".\\resources\\log4j.properties");
		Logger logger = Logger.getLogger(Log4jDemo.class);
		logger.error("This is my error message.");
		logger.info("This is my info message.");
		logger.debug("This is my debug message.");
		logger.warn("This is my warn message.");
		logger.fatal("This is my fatal message.");
	}

}
