import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class Log4jDemo2 {

	public static void main(String[] args) {
		PropertyConfigurator.configure(".\\resources\\log4j_1.properties");
		Logger log = Logger.getLogger(Log4jDemo2.class);
		for(int i=1 ; i<50000; i++) {
			System.out.println("Counter = " + i);
			log.debug("This is my debug message. Counter = " + i);
			log.error("This is my error message. Counter = " + i);
        }
  }


	}

