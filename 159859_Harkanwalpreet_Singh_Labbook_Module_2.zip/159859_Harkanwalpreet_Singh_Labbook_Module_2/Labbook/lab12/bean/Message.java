package bean;

import org.apache.log4j.Logger;

public class Message {
	Logger logger = Logger.getLogger(Message.class);
	public Message(){
	}
	private String msg;
	
	public void setMessage(String msg) {
		this.msg = msg;
		logger.fatal("This is my fatal message.");
	}

	public String getMessage() {
		logger.fatal("This is my fatal message.");
		return msg;
	}

}
