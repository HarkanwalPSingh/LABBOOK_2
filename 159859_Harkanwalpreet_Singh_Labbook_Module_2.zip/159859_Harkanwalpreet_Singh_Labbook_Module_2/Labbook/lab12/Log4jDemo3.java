import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import bean.Message;

public class Log4jDemo3 {

//create a logger for Log4jDemo3 class
public static void main(String args[]) {
	PropertyConfigurator.configure(".\\resources\\log4j.properties");
	Logger logger = Logger.getLogger(Log4jDemo3.class);
Message msgMessage = new Message();
msgMessage.setMessage("Hello World");
System.out.println(msgMessage.getMessage());
logger.fatal("This is my fatal message.");
}
}

