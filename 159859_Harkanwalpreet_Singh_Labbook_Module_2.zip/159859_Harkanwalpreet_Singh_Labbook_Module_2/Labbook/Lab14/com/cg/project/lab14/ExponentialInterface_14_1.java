//14.1
package com.cg.project.lab14;

public interface ExponentialInterface_14_1 
{
	public abstract double exp(int x, int y);

}
