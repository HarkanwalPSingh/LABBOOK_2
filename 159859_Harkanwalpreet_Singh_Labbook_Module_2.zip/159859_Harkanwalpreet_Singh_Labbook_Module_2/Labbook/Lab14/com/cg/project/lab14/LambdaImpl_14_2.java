package com.cg.project.lab14;

public interface LambdaImpl_14_2 
{
	
	public static void main(String[] args) {
		
	
	LambdaInterface_14_2 lm = (str) -> 
						 {
							String temp="";
							for(int i=0;i<str.length();i++)
							{
								temp = temp + str.charAt(i) + " "; 
										
							}
							 return temp; 
						 };
	System.out.println(lm.modifyString("Aravinda"));
	}
}
