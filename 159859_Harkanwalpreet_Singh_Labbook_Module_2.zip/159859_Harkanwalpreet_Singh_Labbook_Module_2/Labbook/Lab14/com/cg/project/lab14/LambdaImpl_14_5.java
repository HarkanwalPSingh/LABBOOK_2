//14.5: Write a method to calculate factorial of a number. Test this method using method reference feature.
package com.cg.project.lab14;

import java.util.Scanner;

public class LambdaImpl_14_5 implements LambdaInterface_14_5
{
	int n;
	@Override
	public void fact(int n) {
		// TODO Auto-generated method stub
		int fact =1;
		for(int i=n;i>=1;i--)
		{
			fact = fact*i;
		}
		System.out.println("factorial is :- " + fact);
	}
	
	
	public LambdaImpl_14_5(int n) {
		super();
		this.n = n;
		fact(n);
	}


	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the number");
		int number = sc.nextInt();
		LambdaInterface_14_5 lm = LambdaImpl_14_5::new;
		lm.fact(number);
	}


}
