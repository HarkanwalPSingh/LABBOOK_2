//14.3
package com.cg.project.lab14;

public interface LambdaInterface_14_3 
{
	public abstract boolean validation(String userName, String password);
}
