//14.5
package com.cg.project.lab14;

public interface LambdaInterface_14_5 
{
	public abstract void fact(int n);
}
